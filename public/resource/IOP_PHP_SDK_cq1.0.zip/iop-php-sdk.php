<?php
class OAuthException extends Exception {
	
}
class IOPOAuth2 {
	public $client_id;
	public $client_secret;
	public $access_token;
	public $refresh_token;
	public $http_code;
	public $url;
	public $host = "http://113.207.120.120:81/ac/";
	public $timeout = 3;
	public $connecttimeout = 3;
	public $ssl_verifypeer = true;
	public $format = 'json';
	public $decode_json = TRUE;
	public $http_info;
	public $useragent = 'IOP OAuth2 v0.1';
	public $debug = FALSE;
	public static $boundary = '';
	function accessTokenURL()  { return $this->host.'/oauth2/token.php'; }
	function authorizeURL()    { return $this->host.'/oauth2/authorize.php'; }
	function apiURL(){ return $this->host.'/api-v1/'; }
	
	function __construct($client_id, $client_secret, $access_token = NULL, $refresh_token = NULL) {
		$this->client_id = $client_id;
		$this->client_secret = $client_secret;
		$this->access_token = $access_token;
		$this->refresh_token = $refresh_token;
	}
	
	/**
	 * 签名
	 * @param $params
	 * @return NULL|string
	 */
	function sig($params){
		if($params == null){
			return null;
		}
		ksort($params);
		$s = '';
		foreach ($params as $k=>$v){
			$s .= $k;
			$s .= '=';
			$s .= $v;
		}
		$sig1 = md5($s);
		
		$sig2 = md5($sig1.$this->client_secret);
		
		return $sig2;
	}
	function getSignedRequest(){
		if(empty($_POST['signed_request'])){
			return '-1';
		}
		return $this->parseSignedRequest($_POST['signed_request']);
	}
	//oauth开放接口
	function get_signed_request(){
		return $this->getSignedRequest();
	}
	function rand_string($len=6,$type='',$addChars='') {
	    $str ='';
	    switch($type) {
	        case 0:
	            $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.$addChars;
	            break;
	        case 1:
	            $chars= str_repeat('0123456789',3);
	            break;
	        case 2:
	            $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.$addChars;
	            break;
	        case 3:
	            $chars='abcdefghijklmnopqrstuvwxyz'.$addChars;
	            break;
	        default :
	            $chars='ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'.$addChars;
	            break;
	    }
	    if($len>10 ) {
	        $chars= $type==1? str_repeat($chars,$len) : str_repeat($chars,5);
	    }
	    $chars   =   str_shuffle($chars);
	    $str     =   substr($chars,0,$len);
	    return $str;
	}
	/**
	 * authorize接口
	 * @param string $url 授权后的回调地址,站外应用需与回调地址一致,站内应用需要填写canvas page的地址
	 * @param string $response_type 支持的值包括 code 和token 默认值为code
	 * @return
	 */
	function getAuthorizeURL( $url, $response_type = 'code',$params = array()) {
		$params['client_id'] = $this->client_id;
		$params['redirect_uri'] = urlencode($url);
		$params['response_type'] = $response_type;
		return $this->authorizeURL() . "?" . http_build_query($params);
	}
	//oauth封装接口
	function get_authorize_url($url, $response_type = 'code'){
		return $this->getAuthorizeURL($url, $response_type);
	}
	
	/**
	 * access_token接口
	 * @param string $type 请求的类型,可以为:code, token
	 * @param array $keys 其他参数：
	 *  - 当$type为code时： array('code'=>..., 'redirect_uri'=>...)
	 *  - 当$type为token时： array('refresh_token'=>...)
	 * @return array
	 */
	function getAccessToken( $type = 'code', $keys ) {
		$keys['client_id'] = $this->client_id;
		$keys['client_secret'] = $this->client_secret;
		if ( $type === 'token' ) {
			$keys['grant_type'] = 'refresh_token';
		} elseif ( $type === 'code' ) {
			$keys['grant_type'] = 'authorization_code';
			//$params['redirect_uri'] = $keys['redirect_uri'];
		}else {
			throw new OAuthException("wrong auth type");
		}
		$response = $this->oAuthRequest($this->accessTokenURL(), 'POST', $keys);
		if ( substr($response, 0, 3)=="\xEF\xBB\xBF"){
				$response=preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response) ;
			}
		//var_dump($response);
		$token = json_decode($response, true);
		if ( is_array($token) && !isset($token['error']) ) {
			$this->access_token = $token['oauth_token'];
			$this->refresh_token = $token['refresh_token'];
		} else {
			throw new OAuthException("get access token failed." . $token['error']);
		}
		return $token;
	}
	//oauth封装接口
	function get_access_token($type = 'code', $keys){
		return $this->getAccessToken($type, $keys);
	}

	/**
	 * 解析 signed_request
	 *
	 * @param string $signed_request 应用框架在加载iframe时会通过向Canvas URL post的参数signed_request
	 *
	 * @return array
	 */
	function parseSignedRequest($signed_request) {
		if(empty($signed_request)){
			return '-1';
		}
		
		$result = json_decode(base64_decode($signed_request),true);
		return $result;
		$sig = $result['sig'];
		unset($result['sig']);
		
		$sig2 = $this->sig($result);
		return ($sig !== $sig2)? '-2':$result;
	}

	/**
	 * @ignore
	 */
	function base64decode($str) {
		return base64_decode(strtr($str.str_repeat('=', (4 - strlen($str) % 4)), '-_', '+/'));
	}

	/**
	 * 读取jssdk授权信息，用于和jssdk的同步登录
	 *
	 * @return array 成功返回array('access_token'=>'value', 'refresh_token'=>'value'); 失败返回false
	 */
	function getTokenFromJSSDK() {
		$key = "weibojs_" . $this->client_id;
		if ( isset($_COOKIE[$key]) && $cookie = $_COOKIE[$key] ) {
			parse_str($cookie, $token);
			if ( isset($token['access_token']) && isset($token['refresh_token']) ) {
				$this->access_token = $token['access_token'];
				$this->refresh_token = $token['refresh_token'];
				return $token;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * 从数组中读取access_token和refresh_token
	 * 常用于从Session或Cookie中读取token，或通过Session/Cookie中是否存有token判断登录状态。
	 *
	 * @param array $arr 存有access_token和secret_token的数组
	 * @return array 成功返回array('access_token'=>'value', 'refresh_token'=>'value'); 失败返回false
	 */
	function getTokenFromArray( $arr ) {
		if (isset($arr['access_token']) && $arr['access_token']) {
			$token = array();
			$this->access_token = $token['access_token'] = $arr['access_token'];
			if (isset($arr['refresh_token']) && $arr['refresh_token']) {
				$this->refresh_token = $token['refresh_token'] = $arr['refresh_token'];
			}

			return $token;
		} else {
			return false;
		}
	}

	/**
	 * GET wrappwer for oAuthRequest.
	 *
	 * @return mixed
	 */
	function get($url, $parameters = array()) {
		$parameters['time'] = time();
		$parameters['client_id'] = $this->client_id;
		$parameters['access_token'] = $this->access_token;
		$signParams=array("time"=>$parameters['time'],"client_id"=>$parameters['client_id'],"resource_name"=>$url);
		$parameters['sig'] = $this->sig($signParams);
		$response = $this->oAuthRequest("{$this->apiURL()}{$url}", 'GET', $parameters);
		//var_dump($response);
		if ($this->format === 'json' && $this->decode_json) {
			if ( substr($response, 0, 3)=="\xEF\xBB\xBF"){
				$response=preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $response) ;
			}
			return json_decode($response, true);
		}
		return $response;
	}

	/**
	 * POST wreapper for oAuthRequest.
	 *
	 * @return mixed
	 */
	function post($url, $parameters = array(), $multi = false) {
		$rand = $this->rand_string(10);
		$parameters['rand'] = $rand;
		$parameters['client_id'] = $this->client_id;
		$parameters['access_token'] = $this->access_token;
		$parameters['sig'] = $this->sig($parameters);
		
		$response = $this->oAuthRequest($url, 'POST', $parameters, $multi );
		if ($this->format === 'json' && $this->decode_json) {
			return json_decode($response, true);
		}
		return $response;
	}

	/**
	 * DELTE wrapper for oAuthReqeust.
	 *
	 * @return mixed
	 */
	function delete($url, $parameters = array()) {
		$response = $this->oAuthRequest($url, 'DELETE', $parameters);
		if ($this->format === 'json' && $this->decode_json) {
			return json_decode($response, true);
		}
		return $response;
	}

	/**
	 * Format and sign an OAuth / API request
	 *
	 * @return string
	 * @ignore
	 */
	function oAuthRequest($url, $method, $parameters, $multi = false) {
		
		$method = "POST";
		switch ($method) {
			case 'GET':
				$url = $url . '?' . http_build_query($parameters);
				return $this->http($url, 'GET');
			default:
				$headers = array();
				if (!$multi && (is_array($parameters) || is_object($parameters)) ) {
					$body = http_build_query($parameters);
				} else {
					$body = self::build_http_query_multi($parameters);
					$headers[] = "Content-Type: multipart/form-data; boundary=" . self::$boundary;
				}
				return $this->http($url, $method, $body, $headers);
		}
	}

	/**
	 * Make an HTTP request
	 *
	 * @return string API results
	 * @ignore
	 */
	function http($url, $method, $postfields = NULL, $headers = array()) {
		$this->http_info = array();
		$ci = curl_init();
		/* Curl settings */
		curl_setopt($ci, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		curl_setopt($ci, CURLOPT_USERAGENT, $this->useragent);
		curl_setopt($ci, CURLOPT_CONNECTTIMEOUT, $this->connecttimeout);
		curl_setopt($ci, CURLOPT_TIMEOUT, $this->timeout);
		curl_setopt($ci, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ci, CURLOPT_ENCODING, "");
		curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, $this->ssl_verifypeer);
		curl_setopt($ci, CURLOPT_HEADERFUNCTION, array($this, 'getHeader'));
		curl_setopt($ci, CURLOPT_HEADER, FALSE);

		switch ($method) {
			case 'POST':
				curl_setopt($ci, CURLOPT_POST, TRUE);
				if (!empty($postfields)) {
					curl_setopt($ci, CURLOPT_POSTFIELDS, $postfields);
					$this->postdata = $postfields;
				}
				break;
			case 'DELETE':
				curl_setopt($ci, CURLOPT_CUSTOMREQUEST, 'DELETE');
				if (!empty($postfields)) {
					$url = "{$url}?{$postfields}";
				}
		}

		if ( isset($this->access_token) && $this->access_token )
			$headers[] = "Authorization: OAuth2 ".$this->access_token;

		$headers[] = "API-RemoteIP: " . $_SERVER['REMOTE_ADDR'];
		curl_setopt($ci, CURLOPT_URL, $url );
		curl_setopt($ci, CURLOPT_HTTPHEADER, $headers );
		curl_setopt($ci, CURLINFO_HEADER_OUT, TRUE );
		
		$response = curl_exec($ci);
		 
		$this->http_code = curl_getinfo($ci, CURLINFO_HTTP_CODE);
		$this->http_info = array_merge($this->http_info, curl_getinfo($ci));
		$this->url = $url;
		if ($this->debug) {
			echo "=====post data======\r\n";
			var_dump($postfields);

			echo '=====info====='."\r\n";
			print_r( curl_getinfo($ci) );

			echo '=====$response====='."\r\n";
			print_r( $response );
		}
		curl_close ($ci);
		return $response;
	}

	/**
	 * Get the header info to store.
	 *
	 * @return int
	 * @ignore
	 */
	function getHeader($ch, $header) {
		$i = strpos($header, ':');
		if (!empty($i)) {
			$key = str_replace('-', '_', strtolower(substr($header, 0, $i)));
			$value = trim(substr($header, $i + 2));
			$this->http_header[$key] = $value;
		}
		return strlen($header);
	}

	/**
	 * @ignore
	 */
	public static function build_http_query_multi($params) {
		if (!$params) return '';

		uksort($params, 'strcmp');

		$pairs = array();

		self::$boundary = $boundary = uniqid('------------------');
		$MPboundary = '--'.$boundary;
		$endMPboundary = $MPboundary. '--';
		$multipartbody = '';

		foreach ($params as $parameter => $value) {

			if( in_array($parameter, array('pic', 'image')) && $value{0} == '@' ) {
				$url = ltrim( $value, '@' );
				$content = file_get_contents( $url );
				$array = explode( '?', basename( $url ) );
				$filename = $array[0];

				$multipartbody .= $MPboundary . "\r\n";
				$multipartbody .= 'Content-Disposition: form-data; name="' . $parameter . '"; filename="' . $filename . '"'. "\r\n";
				$multipartbody .= "Content-Type: image/unknown\r\n\r\n";
				$multipartbody .= $content. "\r\n";
			} else {
				$multipartbody .= $MPboundary . "\r\n";
				$multipartbody .= 'content-disposition: form-data; name="' . $parameter . "\"\r\n\r\n";
				$multipartbody .= $value."\r\n";
			}

		}

		$multipartbody .= $endMPboundary;
		return $multipartbody;
	}
}


/**
 * iCity365开放平台操作类V2
 *
 */
class IOPClient
{
	public $oauth;
	function __construct( $client_id, $client_secret, $access_token, $refresh_token = NULL)
	{
		$this->oauth = new IOPOAuth2($client_id, $client_secret, $access_token, $refresh_token);
	}
	/***
	 * 通用方法，调用该方法直接传入 mod/act以及参数即可
	 * $command为调用的接口 mod/act格式
	 * $params为调用接口传递的参数,格式为array();
	 */
	function sendCommand($command,$params=''){
		return $this->oauth->get($command, $params);
	}
	function getQrcode($v){
		return $this->oauth->get('tools/qrcode', array('value'=>$v));
	}
	/**
	 * 获取身份
	 * @access public
	 * @return array
	 */
	function R_SFZH( $SFZH , $LikeType = 'no', $TOP = 1 )
	{	
		$params = array();
		$params['SFZH'] = $SFZH;
		$params['LikeType'] = $LikeType;
		$params['TOP'] = intval($TOP);
		return $this->oauth->get('checkuser/R_SFZH', $params);//可能是接口的bug不能补全
	}
	
	/**
	 * @ignore
	 */
	protected function id_format(&$id) {
		if ( is_float($id) ) {
			$id = number_format($id, 0, '', '');
		} elseif ( is_string($id) ) {
			$id = trim($id);
		}
	}
	/*以下是uc提供的开放接口，scope定义为用户读写接口，mod=user*/

	/**
	 * OAuth授权之后，获取授权用户的UID
	 * @access public
	 * @return array
	 */
	function get_uid()
	{
		return $this->oauth->get( 'basic_user_info/get_uid' );
	}
	/**
	 * 获取当前用户相关信息，其中包括用户基本信息、关注分组信息、黑名单信息、粉丝信息
	 * @param (int) $uid：用户id
	 * @return (Map)$res用户相关信息，其中包括用户基本信息([user_basic])、关注分组信息([user_follow])、黑名单信息([user_black_list])、粉丝信息([user_fans])
	*/
/* 	function get_user_info($uid){
		$param = array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'basicUserInfo/get_user_info',$param);
	} */
	function get_user_info(){
		return $this->oauth->get( 'basic_user_info/get_user_info');
	}
/**
 * 获取当前用户的黑名单列表
 * @param (int) $uid:用户的id
 * @return List<Map>$res用户的基本信息
 */
/* 	function get_balcklist($uid){
		$param = array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'relationship/get_balcklist',$param);
	} */
	function get_balcklist(){
		return $this->oauth->get( 'relationship/get_balcklist');
	}
/**
	 * 根据用户ID获取粉丝列表
	 * @param (int) $uid:用户的id
	 * @return List<Map>$res用户的基本信息
	 */
	function get_fanslist($uid){
		$param = array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'relationship/get_fanslist',$param);
	}
/**
 * 根据用户ID获取带分页的粉丝列表（分页处理）
 * @param (int)$uid:用户ID
 * @param (int)$showPage:当前页，默认$showPage=1
 * @param (int)$pageSize:当前页显示条数，默认$pageSize=10
 * @return (Map)$res 粉丝列表的信息
 * */
	function get_fanslist_page($uid,$showPage,$pageSize){
		$param =array();
		$param['uid'] = $uid;
		$param['showPage'] = $showPage;
		$param['pageSize'] = $pageSize;
		return $this->oauth->get( 'relationship/get_fanslist_page',$param);
	}
/**
 * 获取当前用户关注的粉丝数量
 * @param (int) $uid:用户
 * @return (int)$res粉丝数量
 */
	function get_fans_num($uid){
		return $this->oauth->get( 'user/get_fans_num');
	}
	/**
	 * 获取当前用户关注的用户数量
	 * @param (int) $uid:用户
	 * @return (int)$res关注的用户数量
	 */
	function get_follows_num($uid){
		return $this->oauth->get( 'user/get_follows_num');
	}
/**
 * 获取当前用户关注的用户信息
 * @param (int) $uid:用户
 * @return List<Map>$res用户的基本信息
 * */
	function get_follower_list($uid){
		return $this->oauth->get( 'user/get_follower_list');
	}
/**
 * 根据用户ID获取带分页的我关注用户信息（分页处理）
 * @param (int)$uid:用户ID
 * @param (int)$showPage:当前页，默认$showPage=1
 * @param (int)$pageSize:当前页显示条数，默认$pageSize=10
 * @return (Map)$res 我关注用户的信息
 * */
	function get_followlist_page($uid,$showPage,$pageSize){
		$param =array();
		$param['uid'] = $uid;
		$param['showPage'] = $showPage;
		$param['pageSize'] = $pageSize;
		return $this->oauth->get( 'relationship/get_followlist_page',$param);
	}
/**
 * 根据用户ID获取用户关注的、尚未分组用户列表
 * @param (int) $uid:用户
 * @return List<Map>$res用户的基本信息
 * */
	function get_user_notin_group($uid){
		$param =array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'group/get_user_notin_group',$param);
	}
/**
 * 根据用户ID获取关注分组信息
 * @param (int)uid:用户ID
 * @return List<Map>$res关注分组信息列表
 * */
	function get_follow_group($uid){
		$param =array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'group/get_follow_group',$param);
	}
/**
 * 根据用户ID获取指定用户的基本信息
 * @param (int) $uid:用户的id
 * @return (Map)$res用户的基本信息
 * */
/* 	function get_user_basicInfo($uid){
		$param =array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'basicUserInfo/get_user_basicInfo',$param);
	} */
	function get_user_basicInfo(){
		return $this->oauth->get( 'basic_user_info/get_user_basicInfo');
	}
/**
 * 获取当前用户指定数量的推荐用户
 * @param (int) $uid:用户的id
 * @param (int) $limit:推荐数量
 * @return (Map)$res推荐用户的信息
 * */
	function get_related_users($limit){
		$param =array();
		$param['limit'] = $limit;
		return $this->oauth->get( 'user/get_related_users',$param);
	}
/**
 * 对外暴露接口
 *
 * 添加关注操作，添加指定用户到指定分组
 * @param (int) $uid:用户的id
 * @param (int) $fid:被关注者的id
 * @param (int) $followGroupId:关注者被添加到指定的分组，$followGroupId = 0，表示未分组
 * @return (boolean)$res 添加成功与否
 */
	function do_follow($uid='',$fid='',$followGroupId='0'){
		$param =array();
		$param['uid'] = $uid;
		$param['fid'] = $fid;
		$param['followGroupId'] = $followGroupId;
		return $this->oauth->get( 'group/do_follow',$param);
	}
	/**
 * 对外暴露接口
 *
 * 创建关注分组
 * @param (String) $title:分组名称
 * @param (int) $uid:被关注者的id
 * @return (int)$res 失败返回-1，成功返回自增主键值
 */
	function add_follow_group($uid='',$title=''){
		$param =array();
		$param['uid'] = $uid;
		$param['title'] = $title;
		return $this->oauth->get( 'group/add_follow_group',$param);
	}
/**
 * 批量删除关注分组，关注分组删除后，该分组下的人会转移到未分组下
 * @param (int) $uid:用户id
 * @param (array) followGroupId:分组名称数组
 * @return (boolean)$res 成功与否
 */
	function delete_follow_groups($uid='',$followGroupId=''){
		$param =array();
		$param['uid'] = $uid;
		$param['followGroupId'] = $followGroupId;
		return $this->oauth->get( 'group/delete_follow_groups',$param);
	}
/**
 * 根据用户ID将已关注用户添加到指定分组中，当参数uid为空时即将已关注用户添加到当前用户的指定分组中
 * @param (int) $uid:用户的id
 * @param (int) $fid:被关注者的id
 * @param (array) $followGroupIds 关注分组id数组
 * @return (boolean)$res 成功与否
 */
	function add_user_group($uid='',$fid,$followGroupIds){
		$param =array();
		$param['uid'] = $uid;
		$param['fid'] = $fid;
		$param['followGroupIds'] = $followGroupIds;
		return $this->oauth->get( 'group/add_user_group',$param);
	}
	
/**
 * 取消关注
 * @param (int) $uid:用户的id
 * @param (int) $fid:被关注者的id
 * @return (boolean)$res 成功与否
 */
	function cancel_follow($fid,$uid=''){
		$param =array();
		$param['uid'] = $uid;
		$param['fid'] = $fid;
		return $this->oauth->get( 'relationship/cancel_follow',$param);
	}
/**
 * 根据用户名nick_name返回用户列表（用户昵称是允许重复的）
 */
	public function get_user_by_name($nick_name) {
		$param['nick_name'] =  $nick_name;
		return $this->oauth->get('user/get_user_by_name',$param);
	}
/**
 * 根据用户名nick_name返回用户列表（用户昵称是允许重复的）
 * @param (String)nick_name:用户昵称
 * @return List<Map>$res用户列表
 * */
	function get_user_page_byname($uid='',$nick_name='',$showPage=1,$pageSize=10){
		$param =array();
		$param['uid'] = $uid;
		$param['nick_name'] = $nick_name;
		$param['showPage'] = $showPage;
		$param['pageSize'] = $pageSize;
		return $this->oauth->get( 'relationship/get_user_page_byname',$param);
	}
/**
 * 根据用户ID获取与当前用户相互关注的用户的信息（分页处理）
 * @param (int)$uid:用户ID
 * @param (int)$showPage:当前页，默认$showPage=1
 * @param (int)$pageSize:当前页显示条数，默认$pageSize=10
 * @return (Map)$res 与当前用户相互关注用户的信息
 * */
	function get_user_each_group($uid='',$showPage=1,$pageSize=10){
		$param =array();
		$param['uid'] = $uid;
		$param['showPage'] = $showPage;
		$param['pageSize'] = $pageSize;
		return $this->oauth->get( 'relationship/get_user_each_group',$param);
	}
/**
 * 根据用户ID获取与当前用户相互关注的用户的数量
 * @param (int)$uid:用户ID
 * @return (int)$res 与当前用户相互关注用户的数量
 */
	function get_group_nums($uid){
		$param =array();
		$param['uid'] = $uid;
		return $this->oauth->get( 'group/get_group_nums',$param);
	}
/**
 * 根据传入的uid和fid判断两个用户的关系
 * @param (int)$uid:用户ID
 * @return (int)$res 0:无联系; 1:uid只关注fid; 2:fid只关注uid; 3:相互关注
 */
	function get_relationship($fid){
		$param =array();
		$param['fid'] = $fid;
		return $this->oauth->get( 'relationship/get_relationship',$param);
	}
/**
 * 获取当前用户关联的自然人信息
 * @param (int)$uid:用户ID
 * @return (Map)$res 自然人信息
 * */
	function get_person_info(){
		return $this->oauth->get( 'user/get_person_info');
	}
/**
 * 获取当前用户关联的法人信息
 * @param (int)$uid:用户ID
 * @return (Map)$res法人信息
 * */
	public function get_organ_by_uid () {
		return $this->oauth->get( 'basicUserInfo/get_organ_by_uid');
	}
	
/**
 * 根据用户类型查询的用户信息
 */
	/**以下是ac提供的开放接口，scope定义为应用读写接口，mod=application*/
	/**
	 * 根据应用apid获取应用详细信息
	 * @param int $app_id
	 */
	function get_app_byid($app_id){
		$param['app_id'] = $app_id;
		return $this->oauth->get('application/get_app_byid',$param);
	}
	/**
	 * 获取应用列表
	 * @param array $appIdList 应用id列表
	 */
	function get_applist($appIdList){
		$param['appIdList'] = $appIdList;
		return $this->oauth->get('application/get_applist',$param);
	}
	/**
	 *  获取应用链接地址
	 * @param array $appData
	 */
	function get_app_entry($appData){
		$param['appData'] = $appData;
		return $this->oauth->get('application/get_app_entry',$param);
	}
	/**
	 * 获取用户最近使用的应用
	 * @param int $uid 用户id
	 * @param int $nums 获取应用个数
	 */
	function get_user_apps($nums){
		$param['nums'] = $nums;
		return $this->oauth->get('application/get_user_apps',$param);
	}
	/**
	 * 获取系统推荐的应用列表
	 * @param int $nums
	 */
	function get_promoted_applist($nums){
		$param['nums'] = $nums;
		return $this->oauth->get('application/get_promoted_applist',$param);
	}
	/**以下是mc提供的接口*/
	/**
	 * 获取我的消息
	 * @param int $uid 用户id
	 */
/* 	function get_user_msg($uid){
		$param['uid'] = $uid;
		return $this->oauth->get('instantMsg/get_user_msg',$param);
	} */
	function get_user_msg(){
		return $this->oauth->get('instant_msg/get_user_msg');
	}
	/**
	 * 获取用户所有类型的未读消息的数目
	 * 数据例子：
	 * ({"rc":1})  //类型:数目
	 **/
	/* function get_unreadmsg_num($uid){
		$param['uid'] = $uid;
		return $this->oauth->get('instantMsg/get_unreadmsg_num',$param);
	} */
	function get_unreadmsg_num(){
		return $this->oauth->get('instant_msg/get_unreadmsg_num');
	}
	/**
	 *  获取当前用户所有的系统消息内容详细列表(用于系统通知、公告之类，关注用户、@用户、加好友、发站内信等不适用)，获取前20条
	 *  返回格式(jsonp)
	 *  数据例子：
	 *  [
	 *   {
	 *    	"type_name": "网盘相关", //分类名称
	 * 		//内容
	 *    	"list": [
	 *     		{
	 *            	"content": "郑仁伟把\"新建文件夹\"3文件夹共享给你，请在共享管理中查看。",
	 *            	"send_time": "2012-12-14 17:06:29",
	 *            	"is_read": "0",
	 *            	"message_type": "rc_docshare_add"
	 *     		},
	 *     		{
	 *            	"content": "郑仁伟把新建文件夹2文件夹共享给你，请在共享管理中查看。",
	 *            	"send_time": "2012-12-14 17:12:10",
	 *            	"is_read": "0",
	 *            	"message_type": "rc_docshare_add"
	 *     		}
	 *		],
	 *		"list_address": null,//链接地址
	 *   	"type_id": "rc", //类型id
	 *   	"parent_id": "-1" //父类型id
	 *	}
	 *  ]
	 **/
	/* function get_notifications($uid){
		$param['uid'] = $uid;
		return $this->oauth->get('instantMsg/get_notifications',$param);
	} */
	function get_notifications(){
		return $this->oauth->get('instant_msg/get_notifications');
	}
	/**
	 * 获取当前用户某种类型的消息内容的列表详细，支持分页查询(用于系统通知、公告之类，关注用户、@用户、加好友、发站内信等不适用)
	 * 返回内容同 getNotificationsAction
	 */
	/* function get_notify_page($uid,$message_type,$start=1,$size=10){
		$param['uid'] = $uid;
		$param['message_type'] = $message_type;
		$param['start'] = $start;
		$param['size'] = $size;
		return $this->oauth->get('instantMsg/get_notify_page',$param);
	} */
	function get_notify_page($message_type,$start=1,$size=10){
		$param['message_type'] = $message_type;
		$param['start'] = $start;
		$param['size'] = $size;
		return $this->oauth->get('instant_msg/get_notify_page',$param);
	}
	/**
	 * 给某些用户增加某种消息的未读计数(适用于关注用户、@用户、加好友。发站内信等)
	 * $uid：用户，多个用户直接用逗号拼接，uid为空，代表为当前用户
	 * $message_type：消息类型
	 * $count：数目  (String)
	 */
	function add_count($message_type, $uid,$count='1'){
		$param['uid'] = $uid;
		$param['message_type'] = $message_type;
		$param['count'] = $count;
		return $this->oauth->get('instant_msg/add_count',$param);
	}
	function add_mid_count($message_type,$count='1'){
		$param['message_type'] = $message_type;
		$param['count'] = $count;
		return $this->oauth->get('instant_msg/add_mid_count',$param);
	}
	/**
	 * 给某些用户增加系统通知(用于系统通知、公告之类，关注、@用户、加好友、发站内信等不适用)
	 * 参数map，参数类型：集合
	 * 属性：#user_id(多个用户之间用逗号分隔)#,#send_id#,#send_name#,#message_type#,#send_time#,#is_read#,#action_url#,#param1#,#param2#,#param3#
	 * return  1成功 ，0失败
	 */
	function add_notification($send_name,$message_type,$uid='',$send_time='',$is_read='',$action_url='',$param1='',$param2='',$param3='')
	{
		$param['uid'] = $uid;
		$param['send_name'] = $send_name;
		$param['message_type'] = $message_type;
		$param['send_time'] = $send_time;
		$param['is_read'] = $is_read;
		$param['action_url'] = $action_url;
		$param['param1'] = $param1;
		$param['param2'] = $param2;
		$param['param3'] = $param3;
		return $this->oauth->get('instant_msg/add_notification',$param);
	}
	function add_mid_notification($send_name,$message_type,$send_time='',$is_read='',$action_url='',$param1='',$param2='',$param3='')
	{
		$param['send_name'] = $send_name;
		$param['message_type'] = $message_type;
		$param['send_time'] = $send_time;
		$param['is_read'] = $is_read;
		$param['action_url'] = $action_url;
		$param['param1'] = $param1;
		$param['param2'] = $param2;
		$param['param3'] = $param3;
		return $this->oauth->get('instant_msg/add_mid_notification',$param);
	}
	/**
	 * 查询某种类型消息的某个范围内的未读用户数，一般用于企业数据分析，性能较差，不建议使用
	 * $msg_type:消息类型
	 * $msg_count：范围
	 */
	function get_spec_unreadmsg($msg_type,$msg_count){
		$param['msg_type'] = $msg_type;
		$param['msg_count'] = $msg_count;
		return $this->oauth->get('instant_msg/get_spec_unreadmsg',$param);
	}
	/**
	 * 获取未读消息的详细内容，包括数目
	 */
	 function get_unread_note(){
		return $this->oauth->get('instant_msg/get_unread_note');
	}
	
}

