package com.inspur.iop.demo;

import com.inspur.iop.OpenApi;
import com.inspur.iop.model.PostParameter;
import com.inspur.iop.oauth.Log;
import com.inspur.iop.util.Configuration;

public class MainDemo {

	public static void main(String[] args) throws Exception {
		Log.logInfo("这是一个客户端测试");
		String client_ID = Configuration.getValue("client_ID");
		String client_SERCRET = Configuration.getValue("client_SERCRET");
		/**
		 * 请求路径，例如/test/1.0
		 */
		String context = "rskswjxx";
		String version =  "1.0";

		OpenApi api = new OpenApi(client_ID, client_SERCRET);
		PostParameter[] params = new PostParameter[2];
		// 说明是客户端的请求
		params[0] = new PostParameter("grant_type", "client_credentials");
		params[1] = new PostParameter("method", "client");
		// 请求参数
		params[2] = new PostParameter("param", "ABS123");
//		String result = api.getResponse(command, params).toString();
		String result = api.getResponse(context, version, "post", params).toString();
		Log.logInfo(result.toString());

	}

}
