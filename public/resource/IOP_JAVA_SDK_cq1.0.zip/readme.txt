Java-SDK V1.0

一. 首先请先填写相关配置：在configuration.properties里
	client_ID ：appkey                           
	client_SERCRET ：app_secret
	redirect_URI : 回调地址
	app_URL : 应用主页地址
	baseURL : URL
	accessTokenURL : 令牌获取URL
	authorizeURL : 授权URL
	
二. iop包下的OpenApi.java文件为开放接口定义类
	在OpenApi.java文件中定义了一个api调用通用方法 sendCommand(String Command,PostParameter[] params)，
	该方法用于处理JSONObject数据，还可以使用getResponse(String Command, PostParameter[] params)，返回一个response对象；
	在数据平台申请相关的接口，申请审批通过后，直接调用sendCommand()方法进行API调用。

三. 运行example/MainDemo.java文件就可以体验oauth2.0授权流程了，如果access_token提示错误，需要自己修改为正确的值。
	access_token可以在web应用授权后，在控制台查看。
	