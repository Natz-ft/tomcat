﻿using System;

namespace iop.sdk
{
    [Serializable]
    public class IOPException : System.Net.WebException
    {
        public IOPException(string message)
            : base(message)
        {
        }

    }
}
