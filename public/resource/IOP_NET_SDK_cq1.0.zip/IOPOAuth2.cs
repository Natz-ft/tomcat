﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Security.Cryptography;


namespace iop.sdk
{
    public class IOPOAuth2
    {
        public string ClientID
		{
			get;
			set;
		}

		public string ClientSecret
		{
			get;
			set;
		}

		public string AccessToken
		{
			get;
			set;
		}

		public string RefreshToken
		{
			get;
			set;
		}

		public string CallbackUrl
		{
			get;
			set;
		}
        public IOPOAuth2(string clientID, string clientSecret)
        {
            ClientID = clientID;
            ClientSecret = clientSecret;
        }
		public IOPOAuth2(string clientID, string clientSecret, string callbackUrl)
		{
			ClientID = clientID;
			ClientSecret = clientSecret;
			CallbackUrl = callbackUrl;
		}


		public IOPOAuth2(string clientID, string clientSecret, string accessToken, string refreshToken)
		{
			ClientID = clientID;
			ClientSecret = clientSecret;
			AccessToken = accessToken;
			RefreshToken = refreshToken;
		}

		public virtual string SendCommand(string command, params RequestParameter[] parameters)
		{
			return SendCommand(command, RequestMethod.Get, parameters);
		}

		public virtual string SendCommand(string command, RequestMethod method, params RequestParameter[] parameters)
		{
           
            if(string.IsNullOrEmpty(AccessToken)){
                return "error:miss AccessToken";
            }

            List<RequestParameter> paramList = parameters.ToList();

            paramList.Add(new RequestParameter() { Name = "client_id", Value = ClientID });
           
            paramList.Add(new RequestParameter() { Name = "access_token", Value = AccessToken });

            DateTime dtstart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            DateTime dtnow = DateTime.Parse(DateTime.Now.ToString());
            TimeSpan tonow = dtnow.Subtract(dtstart);
            string timestamp = tonow.Ticks.ToString();
            timestamp = timestamp.Substring(0, timestamp.Length - 7);
            paramList.Add(new RequestParameter() { Name = "time", Value = timestamp });

            List<RequestParameter> config = new List<RequestParameter>()
			{
				new RequestParameter(){ Name= "client_id", Value= ClientID},
				new RequestParameter(){ Name="resource_name", Value=command},
                new RequestParameter() { Name = "time", Value = timestamp }
			};
            RequestParameter[] parameter = config.ToArray();
            paramList.Add(new RequestParameter() { Name = "sig", Value = sig(parameter) });

            parameters = paramList.ToArray();
           
			return Request(GetCommandUrl(command), method, parameters);
		}

		
		protected string GetCommandUrl(string command)
        {
            string url = string.Empty;
            
			if (command.StartsWith("http://") || command.StartsWith("https://"))
			{
				url = command;
			}
			else
			{
                url = BaseAPIUrl + command;
			}
            
			return url;
        }

        protected string BaseHostURL
        {
            get { return "http://113.207.120.120:81/ac"; }
        }

		protected string BaseAPIUrl
		{
            get { return BaseHostURL + "/api-v1/"; }
		}

		protected string AuthorizeUrl
		{
            get { return BaseHostURL + "/oauth2/authorize.php"; }
		}

		protected string AccessTokenUrl
		{
            get { return BaseHostURL + "/oauth2/token.php"; }
		}

        public string GetAuthorizeUrl(ResponseType response,  params RequestParameter[] parameters)
		{
            if ( !Enum.IsDefined(typeof(ResponseType), response) )
            {
                response = ResponseType.Code;
            }

            String  state, forcelogin;
             List<RequestParameter> paramList = parameters.ToList();
           
                state =(String) paramList[0].Value;
                forcelogin=(String)paramList[1].Value;
            
           
			Dictionary<string, object> config = new Dictionary<string, object>()
			{
				{"client_id",ClientID},
				{"redirect_uri",CallbackUrl},
				{"response_type",response.ToString().ToLower()},
                {"state",state},
                {"forcelogin",forcelogin},
			};
			UriBuilder builder = new UriBuilder(AuthorizeUrl);

			builder.Query = Utility.BuildQueryString(config);

			return builder.ToString();
            
		}
        //获得认证地址
        public string GetAuthorizeUrl( params RequestParameter[] parameters)
        {
            return GetAuthorizeUrl(ResponseType.Code, parameters);
        }

        /// <summary>
		/// 使用code方式获取AccessToken
		/// </summary>
		/// <param name="code">Code</param>
		/// <returns></returns>
		public string GetAccessTokenByAuthorizationCode(string code, String state)
        {
            
			return GetAccessToken(GrantType.AuthorizationCode, new Dictionary<string, string> {
				{"code",code},
				{"redirect_uri",  CallbackUrl},
                {"state",state}
			});
		}


        internal string GetAccessToken(GrantType type, Dictionary<string, string> parameters)
        {
           
            List<RequestParameter> config = new List<RequestParameter>()
			{
				new RequestParameter(){ Name= "client_id", Value= ClientID},
				new RequestParameter(){ Name="client_secret", Value=ClientSecret},
                new RequestParameter() { Name = "rand", Value = Utility.GetBoundary() }
			};

            switch (type)
            {
                case GrantType.AuthorizationCode:
                    {
                        config.Add(new RequestParameter() { Name = "grant_type", Value = "authorization_code" });
                        config.Add(new RequestParameter() { Name = "code", Value = parameters["code"] });
                        config.Add(new RequestParameter() { Name = "redirect_uri", Value = parameters["redirect_uri"] });
                        config.Add(new RequestParameter() { Name = "state", Value = parameters["state"] });
                    }
                    break;
                case GrantType.Password:
                    {
                        config.Add(new RequestParameter() { Name = "grant_type", Value = "password" });
                        config.Add(new RequestParameter() { Name = "username", Value = parameters["username"] });
                        config.Add(new RequestParameter() { Name = "password", Value = parameters["password"] });
                    }
                    break;
                case GrantType.RefreshToken:
                    {
                        config.Add(new RequestParameter() { Name = "grant_type", Value = "refresh_token" });
                        config.Add(new RequestParameter() { Name = "refresh_token", Value = parameters["refresh_token"] });
                    }
                    break;
            }

            var response = Request(AccessTokenUrl, RequestMethod.Post, config.ToArray());

            if (!string.IsNullOrEmpty(response))
            {
                var json = JsonHelper.Parse(response);
                Dictionary<String, Object> j = (Dictionary<String, Object>)json;
                if (j.ContainsKey("error"))
                {
                   // Console.WriteLine(j.ContainsKey("error"));
                    return null;
                }
                else
                {
                    if (j.ContainsKey("state"))
                    { 
                        String state=json["state"].ToString();
                        if (state != parameters["state"])
                        {
                            Console.WriteLine("cross-site request forgery  where get token");
                            return null;
                        }
                    } 
                    if (j.ContainsKey("oauth_token"))
                    {
                        AccessToken = json["oauth_token"].ToString();
                    }
                    //Console.WriteLine(AccessToken);
                    return AccessToken;
                }
            }
            else
            {
                return null;
            }
        }

        //签名
        internal string sig(params RequestParameter[] parameters)
        {
            if(parameters == null){
			    return null;
		    }

            int len = parameters.Length;
            //Type type = typeof(RequestParameter);
            //object [] keys = new object[len];
            string[] keys = new string[len];
            for (int i = 0; i < len; i++)
            {
                //keys[i] = type.InvokeMember("Name", BindingFlags.GetField, null, parameters[i], null);
                keys[i] = parameters[i].Name;
            }

            Array.Sort(keys,parameters);

		    string s = string.Empty;
            
            foreach (var item in parameters)
			{
				s += item.Name + "=" + item.Value;
			}

            MD5 m = new MD5CryptoServiceProvider();

            string s1 = BitConverter.ToString(m.ComputeHash(UnicodeEncoding.UTF8.GetBytes(s)));
            //Console.WriteLine("--1---:" + s); 

            s1 = s1.Replace("-", "");

            s1 = s1.ToLower();

            string s2 = BitConverter.ToString(m.ComputeHash(UnicodeEncoding.UTF8.GetBytes(s1 + ClientSecret)));
           
            s2 = s2.Replace("-", "");

            s2 = s2.ToLower();
           
		    return s2;
        }

		protected string Request(string url, RequestMethod method, params RequestParameter[] parameters)
		{
            if ( !Enum.IsDefined(typeof(RequestMethod), method) )
            {
                method = RequestMethod.Get;
            }

			UriBuilder uri = new UriBuilder(url);
			string result = string.Empty;

			bool multipart = false;

			foreach (var item in parameters)
			{
				if (item.IsBinaryData)
				{
					multipart = true;
					break;
				}
			}

			switch (method)
			{
				case RequestMethod.Get:
					{
						uri.Query = Utility.BuildQueryString(parameters);
					}
					break;
				case RequestMethod.Post:
					{
						if (!multipart)
						{
							uri.Query = Utility.BuildQueryString(parameters);
						}
					}
					break;
			}

			HttpWebRequest http = WebRequest.Create(uri.Uri) as HttpWebRequest;
			http.ServicePoint.Expect100Continue = false;
			http.UserAgent = "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0)";

			if (!string.IsNullOrEmpty(AccessToken))
			{
				http.Headers["Authorization"] = string.Format("OAuth2 {0}", AccessToken);
			}

			switch (method)
			{
				case RequestMethod.Get:
					{
						http.Method = "GET";
					}
					break;
				case RequestMethod.Post:
					{
						http.Method = "POST";

						if (multipart)
						{
							string boundary = Utility.GetBoundary();
							http.ContentType = string.Format("multipart/form-data; boundary={0}", boundary);
							http.AllowWriteStreamBuffering = true;
							using (Stream request = http.GetRequestStream())
							{
								try
								{
									var raw = Utility.BuildPostData(boundary, parameters);
									request.Write(raw, 0, raw.Length);
								}
								finally
								{
									request.Close();
								}
							}
						}
						else
						{
							http.ContentType = "application/x-www-form-urlencoded";

							using (StreamWriter request = new StreamWriter(http.GetRequestStream()))
							{
								try
								{                                 
									request.Write(Utility.BuildQueryString(parameters));
								}
								finally
								{
									request.Close();
								}
							}
						}
					}
					break;
			}

			try
			{
				using (WebResponse response = http.GetResponse())
				{

					using (StreamReader reader = new StreamReader(response.GetResponseStream()))
					{
						try
						{
							result = reader.ReadToEnd();
						}
						catch (System.Net.WebException)
						{
							throw;
						}
						finally
						{
							reader.Close();
						}
					}


					response.Close();
				}
			}
			catch (System.Net.WebException webEx)
			{
				if (webEx.Response != null)
				{
					using (StreamReader reader = new StreamReader(webEx.Response.GetResponseStream()))
					{
						string errorInfo = reader.ReadToEnd();
						
						reader.Close();

						throw new IOPException(errorInfo);
					}
				}
				else
				{
					throw new IOPException(webEx.Message);
				}

			}
			catch
			{
				throw;
			}
			return result;

		}

        protected String BreakString(String input)
        {
            //输入字符串转为字符数组
            int strLen = input.Length;
            char[] chInput = input.ToCharArray();

            //随机数
            Random rand = new Random();

            for (int count = 0; count < strLen * 10; count++)
            {
                int random1 = rand.Next(strLen);
                int random2 = rand.Next(strLen);
                //交换字符
                char temp = chInput[random1];
                chInput[random1] = chInput[random2];
                chInput[random2] = temp;
            }

            return new string(chInput);
        }
        public String Rand_string(int len, String type,String addChars)
        {
            
            String str="";
            String chars="";
            switch(type)
            {
                case "0":
                    chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"+addChars;
                    break;
                case "1":
                    for(int i=0; i< 3; i++)
                    chars= str.PadLeft(10, '$').Replace("$", "0123456789");
                    break;
                case "2":
                     chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ"+addChars;
                    break;
                case "3":
                     chars="abcdefghijklmnopqrstuvwxyz"+addChars;
                    break;
                default :
	                chars="ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"+addChars;
	            break;
            }
            String a="";
            if (len > 10)
            {
                int j;
                j = type == "1" ? len : 5;
                
                for (int i = 0; i < j; i++)
                {

                    a += chars;
                }  
            }
            if(a!="")
            {
                 chars = BreakString(a);
            }
            chars = BreakString(chars);
            return chars.Substring(0, len);
        }
    }
}
