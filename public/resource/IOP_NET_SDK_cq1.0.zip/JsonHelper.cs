﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using System.Collections;

namespace iop.sdk
{
    class JsonHelper
    {
        public static Dictionary<String,Object> Parse(string json)
        {
            //Console.WriteLine(json);
            var jser = new JavaScriptSerializer();
            var o = jser.Deserialize<Dictionary<String, Object>>(json);
            return o;
        }

        /// <summary>
        /// 临时用处理字符串的方式获取json值，以后需要替换掉现在的实现方式
        /// </summary>
        /// <param name="json"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static object GetValueByKey(string json, string key)
        {
            Dictionary<string, object> dd = json.Trim(new char[] { '{', '}' }).Split(',')
                                    .ToDictionary(s => s.Split(':')[0].Trim('"'), s => (object)s.Split(':')[1].Trim('"'));
            return dd[key];
        }
    }
}
